from selenium.webdriver.common.by import By

class LoginPage:
    def __init__(self, driver):
        self.driver = driver

    def abrir(self):
        self.driver.get("https://tusitio.com/login")

    def ingresar_usuario(self, usuario):
        self.driver.find_element(By.ID, "username").send_keys(usuario)

    def ingresar_contraseña(self, contraseña):
        self.driver.find_element(By.ID, "password").send_keys(contraseña)

    def hacer_login(self):
        self.driver.find_element(By.ID, "loginBtn").click()
