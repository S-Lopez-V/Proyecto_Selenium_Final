from pages.login_page import LoginPage

def test_login_correcto(driver):
    login = LoginPage(driver)
    login.abrir()
    login.ingresar_usuario("admin")
    login.ingresar_contraseña("1234")
    login.hacer_login()
    assert "Dashboard" in driver.title
