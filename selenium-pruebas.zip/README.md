# Pruebas Automatizadas con Selenium

Este repositorio contiene scripts de prueba usando Selenium WebDriver en Python.

## Requisitos

- Python 3.x
- pip

## Instalación

```bash
pip install -r requirements.txt
```

## Ejecutar pruebas

```bash
pytest
```